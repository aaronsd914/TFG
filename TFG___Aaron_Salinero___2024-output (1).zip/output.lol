\contentsline {lstlisting}{\numberline {4.1}{\ignorespaces Ejemplo: modelo ORM y schema Pydantic de un cliente.}}{20}{lstlisting.4.1}%
\contentsline {lstlisting}{\numberline {4.2}{\ignorespaces Asignación a segmentos RFM.}}{23}{lstlisting.4.2}%
\contentsline {lstlisting}{\numberline {5.1}{\ignorespaces Configuración de base de datos para pruebas (conftest.py).}}{28}{lstlisting.5.1}%
\contentsline {lstlisting}{\numberline {5.2}{\ignorespaces start.sh --- arranque en producción con migración automática.}}{36}{lstlisting.5.2}%
